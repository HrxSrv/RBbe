def main():
    print("Hello from recruitbotv2!")


if __name__ == "__main__":
    main()
